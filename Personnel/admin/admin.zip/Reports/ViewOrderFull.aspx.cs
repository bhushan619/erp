﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Personnel_employee_View_Order_Full : System.Web.UI.Page
{
    public MySql.Data.MySqlClient.MySqlDataReader dr;
    DatabaseConnection dbc = new DatabaseConnection();
    static int packing = 0, orderrow = 1, custId = 0, prices = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminid"] == null)
        {
            Response.Write("<script>alert('Please Try Again');window.location='../../../login.aspx';</script>");
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
        }

        else if (Session["orderid"] == null)
        {
            Response.Write("<script>alert('Please Try Again');window.location='View Order.aspx';</script>");

        }
        else if (!IsPostBack)
        {
            getImage();
            getempname();
            lblOrderNo.Text = Session["orderid"].ToString();
            SqlDataSource3.SelectCommand = "SELECT distinct CONCAT(nvarProductName,' ',nvarProductSubType ,' ', intSize,' ', varUnit) as ProductName FROM sanghaviunbreakables.tblsuproducts where nvarStatus!='-'";
            setbuttons();
            getData();
            notifications();
        }
    }
    public void notifications()
    {
        lnkNotifications.Text = dbc.count_tblsunotifications(Convert.ToInt32(Session["adminid"].ToString()), "Admin").ToString();
    }
    public void setbuttons()
    {
        if (dbc.get_OrderStatus(Convert.ToInt64(lblOrderNo.Text)) == "Approved")
        {
            //lnkApprove.Enabled = false;
            //lnkReject.Enabled = false; 
            //lnkApprove.CssClass = "btn btn-success disabled";
            //lnkReject.CssClass = "btn btn-danger disabled";
            lstOrderDetails.Enabled = false;
            btnUpdate.Enabled = false;
            btnReset.Enabled = false;
          
            btnUpdate.CssClass = "btn btn-info disabled";
            btnReset.CssClass = "btn btn-danger disabled";
        }
        else
        {
            //lnkApprove.Enabled = true;
            //lnkReject.Enabled = true;
            lstOrderDetails.Enabled = true;
            btnUpdate.Enabled = true;
            btnReset.Enabled = true;
        }
    }
    public void getData()
    {
        try
        {
            dbc.con.Open();
            DataSet ds = new DataSet();
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand("SELECT intOrderId, varBookingId,(SELECT varCompanyName from sanghaviunbreakables.tblsucustomer WHERE (intId =" + Session["empcustid"] + ") ) as comname,(SELECT varMobile from sanghaviunbreakables.tblsucustomer WHERE (intId = " + Session["empcustid"] + ") ) as mobile, varStatus, dtDate, varProductTotal, varTotalNag, varPriceTotal FROM sanghaviunbreakables.tblsuorder WHERE (intOrderId = " + Session["orderid"] + ")", dbc.con);
            MySql.Data.MySqlClient.MySqlDataAdapter adp = new MySql.Data.MySqlClient.MySqlDataAdapter(cmd);

            adp.Fill(ds);
            listorder.DataSource = ds;
            listorder.DataBind();

            MySql.Data.MySqlClient.MySqlDataReader dr1;
            dr1 = cmd.ExecuteReader();
            if (dr1.Read())
            {
                txtBookingId.Text = dr1["varBookingId"].ToString();
                txtTotalPrice.Text = dr1["varPriceTotal"].ToString();
            }
            dbc.con.Close();
            cmd.Dispose();
            adp.Dispose();

            dbc.con.Open();
            DataSet dt = new DataSet();
            cmd = new MySql.Data.MySqlClient.MySqlCommand("SELECT distinct CONCAT(nvarProductName,' ',nvarProductSubType ,' ', intSize,' ', varUnit) as ProductName FROM sanghaviunbreakables.tblsuproducts where nvarStatus!='-'", dbc.con);
            adp = new MySql.Data.MySqlClient.MySqlDataAdapter(cmd);
            adp.Fill(dt);
            lblProductName.DataSource = dt;
            lblProductName.DataBind();
            dbc.con.Close();

        }
        catch (Exception ex)
        {
            dbc.con.Close();
        }



    }
    public void getempname()
    {
        try
        {

            dbc.con.Open();
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand("SELECT varName FROM sanghaviunbreakables.tblsupersonnel where intId=" + Session["adminid"].ToString() + "", dbc.con);

            dbc.dr = cmd.ExecuteReader();
            if (dbc.dr.Read())
            {
                lblCustName.Text = dbc.dr["varName"].ToString();

                dbc.con.Close();
                dbc.dr.Close();
            }

        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Please Try Again');</script>");
        }
    }
    public void getImage()
    {
        try
        {
            string ImageUr = dbc.select_empProfilePic(Convert.ToInt32(Session["adminid"].ToString()));
            if (ImageUr == "")
            {
                imgProPic.ImageUrl = "~/Personnel/employee/media/NoProfile.png";
            }
            else
            {

                imgProPic.ImageUrl = "~/Personnel/employee/media/" + ImageUr;
            }

        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Please Try Again');</script>");
        }
        //  SqlDataSourceMedia.SelectCommand = "SELECT [imgImage] FROM tblsucustomer where intId=" + Convert.ToInt32(Session["adminid"].ToString()) + "";
    }


    protected void lnkLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Session.Clear();
        Session["adminid"] = "";
        Session.Remove("adminid");

        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetNoStore();

        Response.Redirect("~/Default.aspx");
    }
    //protected void lnkApprove_Click(object sender, EventArgs e)
    //{
    //    int updateok = dbc.Update_OrderStatus(Convert.ToInt64(Session["orderid"].ToString()), "Approved", lblCustName.Text);
    //    if (updateok == 1)
    //    {
    //        Response.Write("<script>alert('Order number : " + Convert.ToInt64(Session["orderid"].ToString()) + "  Approved');window.location='ViewOrder.aspx';</script>");
    //    }
    //    else
    //    {
    //        Response.Write("<script>alert('Please try again');window.location='ViewOrder.aspx';</script>");
    //    }
    //}

    //protected void lnkReject_Click(object sender, EventArgs e)
    //{
    //    int updateok = dbc.Update_OrderStatus(Convert.ToInt64(Session["orderid"].ToString()), "Rejected", lblCustName.Text);
    //    if (updateok == 1)
    //    {
    //        Response.Write("<script>alert('Order number : " + Convert.ToInt64(Session["orderid"].ToString()) + "  Rejected');window.location='ViewOrder.aspx';</script>");
    //    }
    //    else
    //    {
    //        Response.Write("<script>alert('Please try again');window.location='ViewOrder.aspx';</script>");
    //    }
    //}

    protected void btnReset_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            if (lblProductName.Text == "-- Select Product --")
            {
                ClientScript.RegisterStartupScript(this.GetType(),
                             "popup",
                             "alert('Please Select Product');",
                             true);
            }
            else
            {
                int updateok = 0;
                int insert_ok_orderdetails = 0;
                if (lblId.Text == "id")
                {
                    insert_ok_orderdetails = dbc.insert_orderdetailsediting(lblOrderNo.Text, lblProductName.Text, txtSack.Text, txtNag.Text, txtPrice.Text, "AddedWhileEditing");
                    if (insert_ok_orderdetails == 1)
                    {

                        ClientScript.RegisterStartupScript(this.GetType(),
                                   "popup",
                                   "alert('Order Updated');window.location='ViewOrderFull.aspx';",
                                   true);
                        clear();
                    }
                }
                else
                {
                    updateok = dbc.updateOrderDetailsFull(txtSack.Text, txtNag.Text, txtPrice.Text, lblId.Text, lblOrderNo.Text,lblProductName.Text);
                    if (updateok == 1)
                    {

                        ClientScript.RegisterStartupScript(this.GetType(),
                                    "popup",
                                    "alert('Order Updated');window.location='ViewOrderFull.aspx';",
                                    true);
                        clear();
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(),
                                   "popup",
                                   "alert('Order Not Updated');",
                                   true);
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void clear()
    {
        lblId.Text = "id";
        lblProductName.Text = "-- Select Product --";
        txtNag.Text = "";
        txtSack.Text = "";
        txtPrice.Text = "";
    }
    protected void txtSack_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtSack.Text == "")
            {
                Response.Write("<script>alert('Sack Value is not Blank ');</script>");
            }
            else if (txtSack.Text == "0")
            {
                Response.Write("<script>alert('Sack Value is not  Zero');</script>");
            }
            else
            {
                txtNag.Text = (packing * Convert.ToInt32(txtSack.Text)).ToString();
                txtPrice.Text = (Convert.ToInt32(txtNag.Text) * Convert.ToInt32(prices)).ToString();
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void txtNag_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtNag.Text == "")
            {
                Response.Write("<script>alert('Nug Value is not Blank ');</script>");
            }
            else if (txtNag.Text == "0")
            {
                Response.Write("<script>alert('Nug Value is not  Zero');</script>");
            }
            else
            {
                txtSack.Text = (Convert.ToInt32(txtNag.Text) / packing).ToString();
                txtPrice.Text = (Convert.ToInt32(txtNag.Text) * Convert.ToInt32(prices)).ToString();
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void lstOrderDetails_ItemCommand(object sender, ListViewCommandEventArgs e)
    {

        try
        {
            if (e.CommandName == "Edita")
            {
                dbc.con.Open();
                dbc.cmd = new MySql.Data.MySqlClient.MySqlCommand("SELECT intId, varProductName, varQuantity, varNag, varPrice FROM tblsuorderdetails WHERE intId=" + Convert.ToInt32(e.CommandArgument) + "", dbc.con);
                dbc.dr = dbc.cmd.ExecuteReader();
                if (dbc.dr.Read())
                {
                    lblId.Text = e.CommandArgument.ToString();
                    lblProductName.Text = dbc.dr[1].ToString();
                    txtSack.Text = dbc.dr[2].ToString();
                    txtNag.Text = dbc.dr[3].ToString();
                    txtPrice.Text = dbc.dr[4].ToString();
                    dbc.con.Close();
                    dbc.dr.Close();
                }
                dbc.con.Close();
                string custstate = dbc.get_CustState(Convert.ToInt32(lblOrderNo.Text));
                string price = string.Empty;
                string myStr = lblProductName.Text;
                string[] ssize = myStr.Split(new char[0]);
                //char[] whitespace = new char[] { ' ', '\t' };
                if (custstate == "Maharashtra" || custstate == "Madhya Pradesh")
                {
                    price = "intMMSMPDealer";
                }
                else
                {
                    price = "intAllStateDealer";
                }
                dbc.con.Open();
                MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand("SELECT " + price + " as prices,intPacking FROM sanghaviunbreakables.tblsuproducts where nvarProductName='" + ssize[0].ToString() + "' and nvarProductSubType='" + ssize[1].ToString() + "' and intSize='" + ssize[2].ToString() + "'", dbc.con);

                dbc.dr = cmd.ExecuteReader();
                if (dbc.dr.Read())
                {
                    prices = Convert.ToInt32(dbc.dr["prices"].ToString());
                    packing = Convert.ToInt32(dbc.dr["intPacking"].ToString());
                    dbc.con.Close();
                    dbc.dr.Close();
                }
            }
            else if (e.CommandName == "Deletea")
            {
                int updateok = 0;
                updateok = dbc.updateOrderDetailsFullDelete(e.CommandArgument.ToString(), lblOrderNo.Text);
                if (updateok == 1)
                {

                    ClientScript.RegisterStartupScript(this.GetType(),
                                "popup",
                                "alert('Order Updated');window.location='ViewOrderFull.aspx';",
                                true);
                    clear();
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(),
                               "popup",
                               "alert('Order Not Updated');",
                               true);
                }
            }
        }
        catch (Exception ex)
        {
            throw;
        }
    }
    protected void ddlProName_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string price = string.Empty;
            string custstate = dbc.get_CustState(Convert.ToInt32(lblOrderNo.Text));
            string myStr = lblProductName.Text;
            string[] ssize = myStr.Split(new char[0]);
            //char[] whitespace = new char[] { ' ', '\t' };
            if (custstate == "Maharashtra" || custstate == "Madhya Pradesh")
            {
                price = "intMMSMPDealer";
            }
            else
            {
                price = "intAllStateDealer";
            }
            dbc.con.Open();
            MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand("SELECT " + price + " as prices,intPacking FROM sanghaviunbreakables.tblsuproducts where nvarProductName='" + ssize[0].ToString() + "' and nvarProductSubType='" + ssize[1].ToString() + "' and intSize='" + ssize[2].ToString() + "'", dbc.con);

            dbc.dr = cmd.ExecuteReader();
            if (dbc.dr.Read())
            {
                txtPrice.Text = dbc.dr["prices"].ToString();
                prices = Convert.ToInt32(dbc.dr["prices"].ToString());
                packing = Convert.ToInt32(dbc.dr["intPacking"].ToString());
                dbc.con.Close();
                dbc.dr.Close();
            }
            txtSack.Text = "";
            txtNag.Text = "";
        }
        catch (Exception ex)
        {
        }

    }
}